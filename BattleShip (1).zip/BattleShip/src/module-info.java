/**
 * 
 */
/**
 * 
 */
module BattleShip {
	requires org.junit.jupiter.api;
}