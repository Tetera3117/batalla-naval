package model;

/**
 * La clase Board representa un tablero de 10x10 para un juego de barcos.
 * Maneja la colocación, eliminación y visualización de los barcos en el tablero.
 */
public class Board {
    // Matriz que representa el tablero del juego
    private final int[][] tablero = new int[10][10];
    
    // Array que contiene los barcos del tablero
    private final Ship[] barcos = new Ship[5];
    
    /**
     * Constructor de la clase Board.
     * Inicializa los barcos con sus respectivos tamaños y números representativos.
     */
    public Board() {
        this.barcos[0] = new Ship(2, 1);
        this.barcos[1] = new Ship(3, 2);
        this.barcos[2] = new Ship(3, 3);
        this.barcos[3] = new Ship(4, 4);
        this.barcos[4] = new Ship(5, 5);
    }
    
    /**
     * Obtiene los barcos en el tablero.
     * 
     * @return un array de barcos presentes en el tablero.
     */
    public Ship[] getBarcos() {
        return barcos;
    }

    /**
     * Coloca un barco en el tablero en las coordenadas dadas, si hay suficiente espacio.
     * Si ya está colocado el barco, se borrara.
     * @param x la posición X (columna) donde se colocará el barco.
     * @param y la posición Y (fila) donde se colocará el barco.
     * @param barco el barco que se desea colocar en el tablero.
     * @return true si el barco se colocó con éxito, false si no hay espacio disponible.
     */
    public boolean setBarco(int x, int y, Ship barco) {
    	boolean completado = false;
    	
    	if(barco.getContador() > 0) {
    		this.deleteBarco(barco);//Borra el barco si ya esta colocado
    	}
    	if(x >= 0 && x < 10 && y >= 0 && y < 10 && barco.getContador() == 0) {
    		if(barco.isVertical()) {
    			if(y <= (10 - barco.getSize())) {
    				if(this.isDespejado(x, y, barco)) {
    					for (int i = y; i < y + barco.getSize(); i++) {
                            tablero[i][x] = barco.getNumero();
                            barco.setPosicion(x, i);
                        }
                        completado = true;
    				}
    			}
    		}
    		else {
    			if (x <= (10 - barco.getSize())) {
    				if(this.isDespejado(x, y, barco)) {
    					 for (int i = x; i < x + barco.getSize(); i++) {
                             tablero[y][i] = barco.getNumero();
                             barco.setPosicion(i, y);
                         }
                         completado = true;
    				}
    			}
    		}	
    	}
    	return completado;
    }

    /**
     * Elimina un barco del tablero, restaurando las posiciones ocupadas a 0.
     * 
     * @param barco el barco que se desea eliminar del tablero.
     */
    public void deleteBarco(Ship barco) {
        for (int i = 0; i < barco.getSize(); i++) {
            this.tablero[barco.getPosicion()[i][1]][barco.getPosicion()[i][0]] = 0;
        }
        barco.setContador(0);
    }

    /**
     * Verifica si la zona está despejada para colocar el barco.
     * 
     * @param x la posición X (columna) inicial para verificar.
     * @param y la posición Y (fila) inicial para verificar.
     * @param barco el barco que se desea colocar.
     * @return true si la zona está despejada, false si hay conflictos con otros barcos.
     */
    public boolean isDespejado(int x, int y, Ship barco) {
        boolean estaDespejado = true;
        
        if (barco.isVertical()) {
            // Verifica si las posiciones verticales están libres
            for (int i = y; i < y + barco.getSize(); i++) {
                if (tablero[i][x] != 0 && tablero[i][x] != barco.getNumero()) {
                    estaDespejado = false;
                }
            }
        } else {
            // Verifica si las posiciones horizontales están libres
            for (int i = x; i < x + barco.getSize(); i++) {
                if (tablero[y][i] != 0 && tablero[y][i] != barco.getNumero()) {
                    estaDespejado = false;
                }
            }
        }
        return estaDespejado;
    }
    
    /**
     * Recibe un misil en una posición específica del tablero y determina si golpea un barco.
     * 
     * @param x Coordenada X en el tablero donde el misil impacta.
     * @param y Coordenada Y en el tablero donde el misil impacta.
     * @return true si el misil golpea un barco, false si impacta en una posición vacía.
     */
    public boolean recibirMisil(int x, int y) {
        // Verifica si las coordenadas están dentro de los límites del tablero
        if (x >= 0 && x < 10 && y >= 0 && y < 10) {
            // Verifica si la posición tiene un barco (diferente de 0)
            if (tablero[y][x] != 0) {
                tablero[y][x] = 0; // Actualiza la posición a vacía
                return true;       // El misil golpeó un barco
            }
        }
        return false; // El misil no golpeó un barco o estaba fuera de los límites
    }
    
    /**
     * Devuelve una representación del tablero.
     * 
     * @return un String que muestra el tablero con los barcos colocados.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("    0   1   2   3   4   5   6   7   8   9\n");
        sb.append("  +---+---+---+---+---+---+---+---+---+---+\n");
        for (int i = 0; i < 10; i++) { 
            sb.append(i).append(" "); 
            for (int j = 0; j < 10; j++) {
                sb.append("| ").append(tablero[i][j]).append(" "); 
            }
            sb.append("|\n"); 
            sb.append("  +---+---+---+---+---+---+---+---+---+---+\n"); 
        }
        return sb.toString();
    }
}
