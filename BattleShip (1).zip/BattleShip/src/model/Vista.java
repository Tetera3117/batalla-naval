package model;

import java.util.Scanner;

public class Vista {
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Board tablero = new Board();
		boolean error = false;
		boolean error1 = false;
		int accion = 1;
		int x = 0;
		int y = 0;
		for(int i = 0 ; i < 5 ; i++) {
			while(accion != 3) {
				switch(accion) {
				case 0:
					do {
						System.out.println("\n\n\n\n\n\n\n\n");
						System.out.println(tablero);
						System.out.println("    +-----------------------------------+");
						System.out.println("    Barco "+(i+1));
						System.out.println("    1. Reubicar   2. Girar   3. Siguiente");
						System.out.print("    Introduzca la accion a hacer: ");
						accion = input.nextInt();
					} while (!(accion > 0 && accion < 4));
					break;
				case 1:
					do {
						System.out.println("\n\n\n\n\n\n\n\n");
						System.out.println(tablero);
						System.out.println("    +-----------------------------------+");
						System.out.println("    Barco "+(i+1)+(error1 ? " ERROR, POSICION INCORRECTA" : " "));
						System.out.print("    Ingrese posicion en horizontal :");
						x = input.nextInt();
						System.out.print("    Ingrese posicion en vertical   :");
						y = input.nextInt();
						error = tablero.setBarco(x, y, tablero.getBarcos()[i]);
						error1 = !error;
					} while(!error);
					accion = 0;
					break;
				case 2:
					tablero.getBarcos()[i].setIsVertical();
					boolean temp = tablero.setBarco(x, y, tablero.getBarcos()[i]);
					if(!temp) {
						tablero.getBarcos()[i].setIsVertical();
						tablero.setBarco(x, y, tablero.getBarcos()[i]);
					}
					accion = 0;
				}
				
				
				
			}
			accion = 1;
			
			
			
			
		}
		
		
	}
	
}
