package model;

/**
 * Clase que representa un barco en el tablero de juego.
 * Un barco tiene un tamaño, un número identificador, una orientación (vertical u horizontal), y una posición en el tablero.
 */
public class Ship {
    private int size; // Tamaño del barco
    private int numero; // Número identificador del barco
    private boolean isVertical; // Indica si el barco está en posición vertical
    private int[][] posicion; // Array que almacena las coordenadas del barco en el tablero
    private int contador; // Contador para seguir el número de coordenadas ingresadas
    private int contadorOrientacion;

    /**
     * Constructor de la clase Ship.
     * 
     * @param size Tamaño del barco.
     * @param numero Número identificador del barco.
     */
    public Ship(int size, int numero) {
        this.numero = numero;
        this.size = size;
        this.isVertical = true;
        this.posicion = new int[size][2];
        this.contador = 0;
        this.contadorOrientacion = 0;
    }

    /**
     * Obtiene el tamaño del barco.
     * 
     * @return Tamaño del barco.
     */
    public int getSize() {
        return size;
    }

    /**
     * Establece el tamaño del barco.
     * 
     * @param size Nuevo tamaño del barco.
     */
    public void setSize(int size) {
        this.size = size;
    }

    /**
     * Obtiene el número identificador del barco.
     * 
     * @return Número identificador del barco.
     */
    public int getNumero() {
        return numero;
    }

    /**
     * Verifica si el barco está en posición vertical.
     * 
     * @return true si el barco es vertical, false si es horizontal.
     */
    public boolean isVertical() {
        return isVertical;
    }

    /**
     * Establece la orientación del barco.
     * 
     * @param isVertical true para vertical, false para horizontal.
     */
    public void setIsVertical() {
    	contadorOrientacion++;
    	this.isVertical = contadorOrientacion % 2 == 0 ? true : false;
    }

    /**
     * Obtiene las coordenadas actuales del barco en el tablero.
     * 
     * @return Array bidimensional con las coordenadas del barco.
     */
    public int[][] getPosicion() {
        return posicion;
    }

    /**
     * Establece la matriz de posiciones del barco.
     * 
     * @param posicion Nueva matriz de posiciones.
     */
    public void setPosicion(int[][] posicion) {
        this.posicion = posicion;
    }

    /**
     * Obtiene el contador actual de posiciones del barco.
     * 
     * @return Contador de posiciones.
     */
    public int getContador() {
        return contador;
    }

    /**
     * Establece el contador de posiciones del barco.
     * 
     * @param contador Nuevo valor para el contador.
     */
    public void setContador(int contador) {
        this.contador = contador;
    }

    /**
     * Ingresa una coordenada en el array bidimensional de posiciones del barco.
     * 
     * @param posicionX Coordenada X en el tablero.
     * @param posicionY Coordenada Y en el tablero.
     */
    public void setPosicion(int x, int y) {
        if (contador < size) {
            this.posicion[contador][0] = x;
            this.posicion[contador][1] = y;
            contador++;
        }
    }
}
