package prueba;

import org.junit.jupiter.api.Test;

import model.Board;

class Pruebas {
	Board tablero = new Board();

	@Test
	void test() {
		tablero.getBarcos()[4].setIsVertical();
		assert(tablero.setBarco(0, 0, tablero.getBarcos()[4]) == true);
		
		
	}

}
